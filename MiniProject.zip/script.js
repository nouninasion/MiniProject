const rows = 10;
const cols = 10;
const startPos = { row: 0, col: 0 };
const goalPos = { row: rows - 1, col: cols - 1 };
const mazeContainer = document.getElementById("maze-container");
const episodeNumberSpan = document.getElementById("episode-number");
const totalRewardSpan = document.getElementById("total-reward");
const epsilonValueSpan = document.getElementById("epsilon-value");
const startButton = document.getElementById("start-button");
const episodeStepsSpan = document.getElementById("episode-steps");
const averageRewardSpan = document.getElementById("average-reward");
const averageStepsSpan = document.getElementById("average-steps");
const bestPathDiv = document.getElementById("best-path");
const bestEpisodeDiv = document.getElementById("best-episode");

let mazeMap = [];
let qTable = {};
const learningRate = 0.3;
const discountFactor = 0.95;
let epsilon = 1.0;
const epsilonDecayRate = 0.002;
const minEpsilon = 0.01;
const numEpisodes = 100;
let currentEpisode = 0;
let episodeRewards = [];
let episodeStepsHistory = [];

function generateRandomMaze() {
  mazeMap = Array(rows)
    .fill(null)
    .map(() => Array(cols).fill("O"));
  mazeMap[startPos.row][startPos.col] = "S";
  mazeMap[goalPos.row][goalPos.col] = "F";

  const obstacleDensity = 0.3; // Peluang munculnya obstacle

  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      if (
        (i !== startPos.row || j !== startPos.col) &&
        (i !== goalPos.row || j !== goalPos.col) &&
        Math.random() < obstacleDensity
      ) {
        mazeMap[i][j] = "#";
      }
    }
  }
}

function getState(pos) {
  return `<span class="math-inline">\{pos\.row\}\-</span>{pos.col}`;
}

function getQValue(state, action) {
  return qTable[state] && qTable[state][action] ? qTable[state][action] : 0;
}

function getValidActions(pos) {
  const { row, col } = pos;
  const actions = ["up", "down", "left", "right"];
  const validActions = [];
  if (row > 0 && mazeMap[row - 1][col] !== "#") validActions.push("up");
  if (row < rows - 1 && mazeMap[row + 1] !== "#") validActions.push("down");
  if (col > 0 && mazeMap[row][col - 1] !== "#") validActions.push("left");
  if (col < cols - 1 && mazeMap[row][col + 1] !== "#")
    validActions.push("right");
  return validActions;
}

function chooseAction(state, validActions) {
  if (Math.random() < epsilon) {
    return validActions[Math.floor(Math.random() * validActions.length)];
  } else {
    let bestAction;
    let maxQ = -Infinity;
    for (const action of validActions) {
      const qValue = getQValue(state, action);
      if (qValue > maxQ) {
        maxQ = qValue;
        bestAction = action;
      }
    }
    return bestAction;
  }
}

function step(pos, action) {
  let { row, col } = pos;
  let newPos = { ...pos };
  let reward = -0.1;
  let done = false;

  switch (action) {
    case "up":
      newPos.row--;
      break;
    case "down":
      newPos.row++;
      break;
    case "left":
      newPos.col--;
      break;
    case "right":
      newPos.col++;
      break;
  }

  if (
    newPos.row < 0 ||
    newPos.row >= rows ||
    newPos.col < 0 ||
    newPos.col >= cols ||
    mazeMap[newPos.row][newPos.col] === "#"
  ) {
    reward = -1;
    newPos = pos;
  } else if (newPos.row === goalPos.row && newPos.col === goalPos.col) {
    reward = 10;
    done = true;
  }

  return { newPos, reward, done };
}

function learn(oldState, action, reward, newState) {
  if (!qTable[oldState]) {
    qTable[oldState] = {};
  }
  const oldQValue = getQValue(oldState, action);
  const newValidActions = getValidActions(newState);
  let maxFutureQ = 0;
  if (newValidActions.length > 0) {
    maxFutureQ = Math.max(
      ...newValidActions.map((a) => getQValue(newState, a))
    );
  }
  const newQValue =
    oldQValue +
    learningRate * (reward + discountFactor * maxFutureQ - oldQValue);
  qTable[oldState][action] = newQValue;
}

function resetAgent() {
  return { ...startPos };
}

function visualizeMaze(agentPos = null, path = []) {
  mazeContainer.innerHTML = "";
  mazeContainer.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      const cell = document.createElement("div");
      cell.classList.add("cell");
      let isPath = false;
      let isBestPath = false;

      if (path.some((p) => p.row === i && p.col === j)) {
        isPath = true;
        const pathPoint = path.find((p) => p.row === i && p.col === j);
        if (pathPoint && pathPoint.isBestPath) {
          isBestPath = true;
        }
      }

      if (mazeMap[i][j] === "#") {
        cell.classList.add("wall");
      } else if (mazeMap[i][j] === "S") {
        cell.classList.add("start");
        cell.textContent = "S";
      } else if (mazeMap[i][j] === "F") {
        cell.classList.add("goal");
        cell.textContent = "F";
      } else if (isPath) {
        cell.classList.add("path");
        if (isBestPath) {
          cell.classList.add("best-path-cell");
        }
      }

      if (agentPos && agentPos.row === i && agentPos.col === j) {
        const agentDiv = document.createElement("div");
        agentDiv.classList.add("agent");
        cell.appendChild(agentDiv);
      }

      mazeContainer.appendChild(cell);
    }
  }
}

async function trainEpisode() {
  let currentPos = resetAgent();
  let episodeReward = 0;
  let steps = 0;
  let done = false;

  while (!done && steps < 300) {
    const state = getState(currentPos);
    const validActions = getValidActions(currentPos);
    if (validActions.length === 0) break;
    const action = chooseAction(state, validActions);
    const { newPos, reward, done: stepDone } = step(currentPos, action);
    const newState = getState(newPos);
    learn(state, action, reward, newState);
    currentPos = newPos;
    episodeReward += reward;
    done = stepDone;
    steps++;

    console.log("Agent Pos:", currentPos);
    console.log("Done:", done, "Steps:", steps); // Tambahkan baris ini
    visualizeMaze(currentPos);
    await new Promise((resolve) => setTimeout(resolve, 1)); // Atau coba 100 untuk melihat pergerakan
  }
  return { reward: episodeReward, steps: steps };
}

function findBestPath() {
  let currentPos = { ...startPos };
  const path = [currentPos];
  let steps = 0;
  while (
    (currentPos.row !== goalPos.row || currentPos.col !== goalPos.col) &&
    steps < 500
  ) {
    const state = getState(currentPos);
    const validActions = getValidActions(currentPos);
    if (validActions.length === 0) {
      break;
    }
    let bestAction;
    let maxQ = -Infinity;
    for (const action of validActions) {
      const qValue = getQValue(state, action);
      if (qValue > maxQ) {
        maxQ = qValue;
        bestAction = action;
      }
    }
    if (bestAction) {
      const { newPos } = step(currentPos, bestAction);
      currentPos = newPos;
      path.push(currentPos);
    } else {
      break; // Tidak ada aksi terbaik, mungkin terjebak
    }
    steps++;
  }
  return path;
}

async function startLearning() {
  startButton.disabled = true;
  episodeRewards = [];
  episodeStepsHistory = [];
  let bestReward = -Infinity;
  let bestEpisode = 0;

  // Generate maze hanya sekali di awal
  generateRandomMaze();
  visualizeMaze(startPos);

  for (let i = 0; i < numEpisodes; i++) {
    currentEpisode = i + 1;
    let totalEpisodeReward = 0;
    let totalEpisodeSteps = 0;
    let currentAgentPos = resetAgent();
    let episodeDone = false;
    let episodeStepCount = 0;

    while (!episodeDone && episodeStepCount < 300) {
      const state = getState(currentAgentPos);
      const validActions = getValidActions(currentAgentPos);
      if (validActions.length === 0) break;
      const action = chooseAction(state, validActions);
      const { newPos, reward, done: stepDone } = step(currentAgentPos, action);
      const newState = getState(newPos);
      learn(state, action, reward, newState);
      currentAgentPos = newPos;
      totalEpisodeReward += reward;
      episodeDone = stepDone;
      episodeStepCount++;
      visualizeMaze(currentAgentPos);
      await new Promise((resolve) => setTimeout(resolve, 1)); // Visualisasi super cepat
    }

    episodeRewards.push(totalEpisodeReward);
    episodeStepsHistory.push(totalEpisodeSteps);

    if (totalEpisodeReward > bestReward) {
      bestReward = totalEpisodeReward;
      bestEpisode = currentEpisode;
    }

    const last50Rewards = episodeRewards.slice(-50);
    const avgReward =
      last50Rewards.reduce((sum, r) => sum + r, 0) / last50Rewards.length || 0;
    const last50Steps = episodeStepsHistory.slice(-50);
    const avgSteps =
      last50Steps.reduce((sum, s) => sum + s, 0) / last50Steps.length || 0;

    episodeNumberSpan.textContent = currentEpisode;
    totalRewardSpan.textContent = totalEpisodeReward.toFixed(2);
    episodeStepsSpan.textContent = episodeStepCount;
    epsilonValueSpan.textContent = epsilon.toFixed(2);
    averageRewardSpan.textContent = avgReward.toFixed(2);
    averageStepsSpan.textContent = avgSteps;

    epsilon = Math.max(minEpsilon, epsilon - epsilonDecayRate);
    await new Promise((resolve) => setTimeout(resolve, 1)); // Delay antar episode super cepat
  }
  startButton.textContent = "Learning Finished";
  const bestPath = findBestPath();
  visualizeMaze(
    null,
    bestPath.slice(1, -1).map((p) => ({ ...p, isBestPath: true }))
  );
  bestPathDiv.textContent = JSON.stringify(
    bestPath.map((p) => `(${p.row}, ${p.col})`)
  );
  bestEpisodeDiv.textContent = `Episode Terbaik: ${bestEpisode} (Reward: ${bestReward.toFixed(
    2
  )})`;
}

// Generate maze pertama kali
generateRandomMaze();
visualizeMaze(startPos);
startButton.addEventListener("click", startLearning);
